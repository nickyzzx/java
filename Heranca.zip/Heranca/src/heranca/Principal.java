package heranca;

import java.util.Scanner;

public class Principal {
 
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       System.out.println("Digite seu nome: ");
       String nome = sc.next();
        
       System.out.println("Digite o cpf: ");
       String cpf = sc.next();
        
       Pessoa p1 = new Pessoa(nome, cpf);
       System.out.println(p1.toString());
       
       System.out.println("Digite o nome do funcionário: ");
       String nomeF = sc.next();
       System.out.println("Digite o cpf do funcionário: ");
       String cpfF = sc.next();
       System.out.println("Digite o salário do funcionário: ");
       double salario = sc.nextDouble();
       
        
       Funcionario f1 = new Funcionario(salario, nomeF, cpfF);
       System.out.println(f1.toString());
    }
    
}
