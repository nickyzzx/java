
package interfaces;

public class Interfaces {

    public static void main(String[] args) {

        Calculo1 c1 = new Calculo1();
        Matematica mat = new Matematica(5, 5);
        
        System.out.println("SOMA. . . . . " + c1.somar(52, 8));
        System.out.println("SUBTRAÇÃO. . . . . " + c1.subtrair(52, 8));
        System.out.println("MULTIPLICAÇÃO. . . . . " + c1.multiplicar(7, 8));
        System.out.println("DIVISÃO. . . . . " + c1.dividir(30, 5));
    }
    
}
