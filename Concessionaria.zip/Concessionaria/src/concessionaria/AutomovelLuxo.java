package concessionaria;

public class AutomovelLuxo extends AutomovelBasico {
    boolean direcaoHidraulica, cambioAutomatico, travasEletricas;

    public AutomovelLuxo(boolean direcaoHidraulica, boolean cambioAutomatico, boolean travasEletricas, String modelo, String cor, int tipoDeCombustivel) {
        super(modelo, cor, tipoDeCombustivel);
        this.direcaoHidraulica = true;
        this.cambioAutomatico = true;
        this.travasEletricas = true;
    }

    public AutomovelLuxo(boolean direcaoHidraulica, boolean cambioAutomatico, boolean travasEletricas, boolean retrovisorPassageiro, boolean limpadorTraseiro, boolean radio, String modelo, String cor, int tipoDeCombustivel) {
        super(retrovisorPassageiro, limpadorTraseiro, radio, modelo, cor, tipoDeCombustivel);
        this.direcaoHidraulica = direcaoHidraulica;
        this.cambioAutomatico = cambioAutomatico;
        this.travasEletricas = travasEletricas;
    }
    
    public double quantoCusta(){
        double preco = super.quantoCusta();
        
        if(direcaoHidraulica){
            preco += 3340;
        }
        if(cambioAutomatico){
            preco += 2190;
        }
        if(travasEletricas){
            preco += 1650;
        }
        return preco;
    }
}
