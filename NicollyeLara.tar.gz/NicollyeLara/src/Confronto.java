
public class Confronto {
    int executar(SuperHeroi superheroi, Vilao vilao){
        int resultado;
        
        if (superheroi.getPoderTotal() > vilao.getPoderTotal()){
            resultado = 1;
        }else if (superheroi.getPoderTotal() < vilao.getPoderTotal()){
            resultado = 2;
        }else{
            resultado = 3;
        }
        return resultado;
    }
    
}
