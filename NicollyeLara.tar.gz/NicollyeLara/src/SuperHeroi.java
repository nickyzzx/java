
public class SuperHeroi extends Personagem {
    public SuperHeroi(String nome, String nomeReal){
        super(nome, nomeReal);
        
    }
    public int getPoderTotal(){
        int soma = (int)(super.getPoderTotal() * 1.1);
        return soma;
    }
}
