package interfaces;

public class Matematica {
    
    private int n1, n2;
    
    public Matematica(){
        
    }
    public Matematica(int n1, int n2) {
        this.n1 = n1;
        this.n2 = n2;
    }
    
    
}
