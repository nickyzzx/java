package appmsg;
import java.net.Socket;
import java.io.DataInputStream;
import java.io.DataOutputStream;

public class Cliente {
    
    public static void main(String[] args) {
        
        try {
            Socket cliente = new Socket("localost", 8080);
            DataInputStream in = new DataInputStream(cliente.getInputStream());
            DataOutputStream out = new DataOutputStream(cliente.getOutputStream());
                    
            out.writeInt(1000);
            System.out.println("Recebido do Servidor" + in.readInt());
            
            in.close();
            out.close();
            cliente.close();
            
        } catch (Exception e) {
            System.out.println("Exceção" + e);
        }
        
    }
}
