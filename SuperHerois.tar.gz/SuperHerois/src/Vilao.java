public class Vilao extends Personagem{
    int tempoDePrisao;

    public Vilao(int tempoDePrisao, String nome, String nomeReal) {
        super(nome, nomeReal);
        this.tempoDePrisao = tempoDePrisao;
    
    }
    
}
