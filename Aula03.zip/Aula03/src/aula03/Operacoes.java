package aula03;
public class Operacoes {    
    private double c, i; //c: capital incial e i: taxa de juros
    private int n; //n: período em meses    
    //o método construtor, obrigatoriamente, tem o mesmo nome da classe
    //o método construtor nao tem tipo de dado de retorno 
    public Operacoes() {
   
    }
    public Operacoes(double c, double i, int n) {
        this.c = c;
        this.i = i;
        this.n = n;        
    }       
    public double montante(){
        double j = c*i*n;             
        return  (c + j) ;
    }    
    public double media(double n1, double n2, double n3){        
        return (n1+n2+n3)/3;        
    }
}
