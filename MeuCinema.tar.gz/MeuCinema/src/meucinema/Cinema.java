
package meucinema;

public class Cinema {
    private int ano;
    private String desc,nome;
    
     public Cinema() {
        
    }

    public Cinema(int ano, String desc, String nome) {
        this.ano = ano;
        this.desc = desc;
        this.nome = nome;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
}
