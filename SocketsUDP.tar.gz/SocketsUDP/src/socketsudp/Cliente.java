package socketsudp;

import java.net.*;
import java.util.Arrays;

public class Cliente {
    
    public static void main(String[] args) {
        
        try {
           DatagramSocket dsCliente = new DatagramSocket();
           InetAddress ip =  InetAddress.getByName("localhost");
           
           byte [] recDados = new byte [512];
           byte [] envDados = new byte [512];
           
           String msg = "oi, hoje é onde?";
           envDados = msg.getBytes();
           
           //monta pacote a ser emv, passando a msg e seu tamanho
           DatagramPacket dpEP = new DatagramPacket(envDados, envDados.length, ip, 8080);
           dsCliente.send(dpEP); //cliente envia pacote 
           
           DatagramPacket dpRD = new DatagramPacket(recDados, recDados.length);
           dsCliente.receive(dpRD);
           
           String msgM = new String(dpRD.getData());
           System.out.println(msgM);
           dsCliente.close();
            
        } catch (Exception e) {
            System.out.println("Exceção: " + e);
        }
        
    }
}
