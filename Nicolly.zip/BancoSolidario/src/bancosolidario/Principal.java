package bancosolidario;

import java.util.Scanner;

public class Principal {
    
    public static void main(String[] args){
      Scanner sc = new Scanner(System.in);   
      Correntista c1 = new Correntista(5678, "Nicolly ", 5000);
      int op = 0;
      while(op !=4){
          System.out.println("Menu de opções: ");
          System.out.println("1. Depositar: ");
          System.out.println("2. Retirar: ");
          System.out.println("3. Ver saldo: ");
          System.out.println("4. Encerrar programa. ");
          op = sc.nextInt();
          
          switch (op){
              case 1:
                  System.out.println("Você escolheu depositar. Informe o valor que vc deseja depositar:  ");
                  double valor = sc.nextDouble();
                  double valorAtual = c1.getSaldo() + valor;
                  c1.setSaldo(valorAtual);
                  break;
              case 2:
                  System.out.println("Você escolheu retirar. Informe o valor que você deseja retirar: ");
                  double valor2 = sc.nextDouble();
                  double valorRetirada = c1.getSaldo() - valor2;
                  c1.setSaldo(valorRetirada);
                  break;
              case 3:
                  System.out.println("Você escolheu ver o saldo. ");
                  System.out.println(c1.toString());
                  break;
              case 4:
                  System.out.println("Programa encerrado. Até mais!");
                  System.exit(0);    
          }
      }
      
     
    }
}
