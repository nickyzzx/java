package concessionaria;

public class DemoAuto {

    public static void main(String[] args) {
        
        Automovel auto = new Automovel("Fusca", "amarelo", 1);
        System.out.println("O preço do " + auto.modelo + " é R$ " + auto.getPreco());
        
        AutomovelBasico autobas = new AutomovelBasico("audi", "vermelho", 2);
        System.out.println("O preço do " + autobas.modelo + " é R$ " + autobas.getPreco());
        
        AutomovelBasico autobas2 = new AutomovelBasico(true, false, false, "jeep", "preto", 1);
        System.out.println("O preço do " + autobas2.modelo + " é R$ " + autobas2.getPreco() );
        
        AutomovelLuxo autoluxo = new AutomovelLuxo(true, true, true, true, true, true, "BMW", "preto", 3);
        System.out.println("O preço do " + autoluxo.modelo + " é R$ " + autoluxo.getPreco());
        
        
    }
    
}
