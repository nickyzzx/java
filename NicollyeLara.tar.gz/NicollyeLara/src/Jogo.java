

public class Jogo {

    public static void main(String[] args) {
        SuperHeroi flash = new SuperHeroi("Flash", "Barry Allen");
        Vilao luthor = new Vilao(10, "Lex Luthor", "Lex Luthor");

        SuperPoder sp1 = new SuperPoder("Velocidade", 5);
        SuperPoder sp2 = new SuperPoder("Força", 5);
        SuperPoder sp3 = new SuperPoder("Voar", 3);
        SuperPoder sp4 = new SuperPoder("Raxio x", 4);
        SuperPoder sp5 = new SuperPoder("Sopro Congelado", 4);
        SuperPoder sp6 = new SuperPoder("Mente Aguçada", 5);

        flash.adicionaSuperpoder(sp1);
        luthor.adicionaSuperpoder(sp6);

        Confronto luta1 = new Confronto();

        switch (luta1.executar(flash, luthor)) {
            case 1:
                System.out.println("O vencedor foi o Flash");
                break;
            case 2:
                System.out.println("O vencedor foi o Luthor");
            default:
                System.out.println("Houve empate.");
                break;
        }

    }

}
