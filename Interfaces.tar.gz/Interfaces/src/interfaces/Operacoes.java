package interfaces;

public interface Operacoes {
    
    int somar(int n1, int n2);
    
    int subtrair(int n1, int n2);
    
    int multiplicar(int n1, int n2);
    
    int dividir(int n1, int n2);
    
}
