package prjavabd;

import java.sql.*;
import java.util.*;
import javax.swing.JOptionPane;

public class Transacoes {
    
    public ArrayList<OrdemServico> consultar(int nos) {        
        Connection con = Conexao.conecta(); //banco
        PreparedStatement stmt = null; //tabela
        ResultSet rs = null; //registros da tabela  
        ArrayList<OrdemServico> linha = new ArrayList<>();
        try {
            stmt = con.prepareStatement("select * from ordem_servico where num_os = " + nos);
            rs = stmt.executeQuery();
            if (rs.next()) {
                OrdemServico os = new OrdemServico();
                os.setNumOS(rs.getInt("num_os"));
                os.setDesc(rs.getString("descricao"));
                os.setStatus(rs.getString("tipo"));                
                
                linha.add(os);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Falha ao consultar registro " + e);
            
        } finally {
            Conexao.fechaConexao(con, stmt, rs);
            
        }
        return linha;        
    }
    
    public void inserir(OrdemServico os) {
        
        Connection con = Conexao.conecta();
        PreparedStatement stmt = null;
        try {
            stmt = con.prepareStatement("insert into ordem_servico "
                    + "(num_os, descricao, tipo) values (?,?,?)");
            
            stmt.setInt(1, os.getNumOS());
            stmt.setString(2, os.getDesc());
            stmt.setString(3, os.getStatus());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null,
                    os.getNumOS() + " inserida com sucesso!");            
        } catch (SQLException e) {
            System.out.println("Falha ao inserir registro" + e);
        } finally {
            Conexao.fechaConexao(con, stmt);
        }
        
    }//fechamento do método    
}//fechamento da classe
