package javabd;
import java.sql.*;
import javax.swing.JOptionPane;


public class Transacoes {
    
    public void inserir(OrdemServico os){
        Connection con =  Conexao.conecta();
        PreparedStatement stmt = null;
        try {
            
           stmt = con.prepareStatement("insert into ordem_servico (num_os, descricao, tipo) values (?, ?, ?);");
           stmt.setInt(1, os.getNumOS());
           stmt.setString(2, os.getDesc());
           stmt.setString(3, os.getStatus());
           stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, os.getNumOS() + "inserida com " + "sucesso!");
        
                   
        } catch (SQLException e) {
            System.out.println("Falha ao inserir registro. " + e); 
        }finally{
            Conexao.fechaConexao(con, stmt);
        }
    }
    
}
