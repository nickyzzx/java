package meucinema;

import java.sql.*;

public class Conexao {
    
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/meubanco";
    private static final String USER = "root";
    private static final String SENHA = "toor";

    public static Connection conecta() {
        Connection con = null;

        try {
            Class.forName(DRIVER);
            con = DriverManager.getConnection(URL, USER, SENHA);

        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Erro na conexão. " + e);
        }

        return con;

    }

    public static void fechaConexao(Connection con) {
        try {
            if (con != null) {
                con.close();
            }

        } catch (SQLException e) {
            System.out.println("Erro ao fechar conexão." + e);
        }
    }

    public static void fechaConexao(Connection con, PreparedStatement stmt) {
        fechaConexao(con);
        try {
            if (stmt != null) {
                stmt.close();
            }

        } catch (SQLException e) {
            System.out.println("Erro ao fechar conexão." + e);

        }

    }

    public static void fechaConexao(Connection con, PreparedStatement stmt, ResultSet rs) {
        fechaConexao(con, stmt);
        try {
            if (rs != null) {
                rs.close();
            }

        } catch (SQLException e) {
            System.out.println("Erro ao fechar conexão." + e);
        }
    }

}

    

