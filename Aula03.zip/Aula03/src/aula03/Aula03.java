package aula03;
import java.util.Scanner;
public class Aula03 {
    public static void main(String[] args) {
        //criando o objeto 'input' p/ leitura de dados
        //Scanner input = new Scanner(System.in);        
        //System.out.println("Digite Nota 1");
        //double n1 = input.nextDouble(); //capturando n1         
        //System.out.println("Digite Nota 2");
        //double n2 = input.nextDouble(); //capturando n2        
        //System.out.println("Digite Nota 3");
        //double n3 = input.nextDouble(); //capturando n3       
        //op representa a "ponte" entre as classes
        //Aula3 e Operacoes
        //Operacoes op = new Operacoes();
        //op está invocando/chamando o método media
        //double media = op.media(n1, n2, n3);               
        //falta formatar p/ 2 casas decimais
        //System.out.println("Média = " + media);
        //System.out.println("Média = " + media2(n1, n2, n3));
        Operacoes op2 = new Operacoes(2000, 0.05, 12);
        System.out.println("Montante = " + op2.montante() );        
    }
    /*
    public static double media2(double n1, double n2, double n3){        
        return (n1+n2+n3)/3;        
    }*/
    
    
}
