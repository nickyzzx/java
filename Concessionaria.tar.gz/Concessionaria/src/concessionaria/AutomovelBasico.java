package concessionaria;

public class AutomovelBasico extends Automovel implements Vendavel {

    boolean retrovisorPassageiro, limpadorTraseiro, radio;

    public AutomovelBasico(boolean retrovisorPassageiro, boolean limpadorTraseiro, boolean radio, String modelo, String cor, int tipoDeCombustivel) {
        super(modelo, cor, tipoDeCombustivel);
        this.retrovisorPassageiro = retrovisorPassageiro;
        this.limpadorTraseiro = limpadorTraseiro;
        this.radio = radio;
    }

    public AutomovelBasico(String modelo, String cor, int tipoDeCombustivel) {
        super(modelo, cor, tipoDeCombustivel);
        retrovisorPassageiro = true;
        limpadorTraseiro = true;
        radio = true;
    }

    @Override
    public double getPreco() {
        double preco = super.getPreco();

        if (retrovisorPassageiro) {
            preco += 280;
        }
        if (limpadorTraseiro) {
            preco += 190;
        }
        if (radio) {
            preco += 320;
        }
        return preco;

    }

    @Override
    public String getDescricao() {
        return modelo + " " + cor + " " + radio;

    }
}
