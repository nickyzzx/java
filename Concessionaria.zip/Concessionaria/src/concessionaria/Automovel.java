package concessionaria;

public class Automovel {
    String modelo, cor;
    int tipoDeCombustivel;

    public Automovel(String modelo, String cor, int tipoDeCombustivel) {
        this.modelo = modelo;
        this.cor = cor;
        this.tipoDeCombustivel = tipoDeCombustivel;
    }
    
    public double quantoCusta(){
        double preco = 0.0;
        switch (tipoDeCombustivel) {
            case 1 -> preco = 20000;
            case 2 -> preco = 19520;
            case 3 -> preco = 25000;
            case 4 -> preco = 22000;
            default -> {
            }
        }
        return preco;
    }
}
