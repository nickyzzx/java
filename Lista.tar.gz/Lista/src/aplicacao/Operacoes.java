
package aplicacao;

public class Operacoes {
    
}
