public class SuperPoder {
    private String superpoder;
    private int categoria;

    public String getSuperpoder() {
        return superpoder;
    }

    public int getCategoria() {
        return categoria;
    }

        
}
