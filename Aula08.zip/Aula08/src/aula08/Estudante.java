package aula08;

public class Estudante {
    
    private String mat, nome, email;

    public Estudante(String mat, String nome, String email) {
        this.mat = mat;
        this.nome = nome;
        this.email = email;
    }

    public String getMat() {
        return mat;
    }

    public void setMat(String mat) {
        this.mat = mat;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
   
}
