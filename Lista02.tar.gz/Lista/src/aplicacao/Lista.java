package aplicacao;

public class Lista {

    public static void main(String[] args) {
        String[] diaSemana1 = {"dom", "seg", "ter", "qua", "qui", "sex", "sab"};
        String[] diaSemana2 = new String[7];
         
        for (int i = 0; i <  diaSemana1.length; i++) {System.out.println("");
            
        }
 
        for (String nome : diaSemana2) {System.out.println(nome);
            
        }
         
        
       
    }
    
}
