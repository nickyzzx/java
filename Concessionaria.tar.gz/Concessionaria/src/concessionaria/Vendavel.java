package concessionaria;

public interface Vendavel {
    
    public String getDescricao();
    public double getPreco(); 
    
}
