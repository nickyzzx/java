package biblioteca02;

import javax.swing.JOptionPane;

public class CadastroDeLivros extends javax.swing.JFrame {

    int cont;
    Livros[] livro = new Livros[5];

    public CadastroDeLivros() {
        initComponents();
        for (int i = 0; i < 5; i++) {
            Livros liv = new Livros("", "", "");
            livro[i] = liv;

        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        lbNome = new javax.swing.JLabel();
        lbAutor = new javax.swing.JLabel();
        lbCod = new javax.swing.JLabel();
        txtAutor = new javax.swing.JTextField();
        txtCod = new javax.swing.JTextField();
        btInserir = new javax.swing.JButton();
        btDel = new javax.swing.JButton();
        btEdit = new javax.swing.JButton();
        btLimpar = new javax.swing.JButton();
        btBusc = new javax.swing.JButton();
        txtNome = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Biblioteca");

        jLabel1.setFont(new java.awt.Font("Noto Sans", 1, 24)); // NOI18N
        jLabel1.setText("Cadastro de Livros");

        lbNome.setFont(new java.awt.Font("Noto Sans", 1, 14)); // NOI18N
        lbNome.setText("NOME");

        lbAutor.setFont(new java.awt.Font("Noto Sans", 1, 14)); // NOI18N
        lbAutor.setText("AUTOR");

        lbCod.setFont(new java.awt.Font("Noto Sans", 1, 14)); // NOI18N
        lbCod.setText("CÓDIGO");

        btInserir.setText("INSERIR");
        btInserir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btInserirActionPerformed(evt);
            }
        });

        btDel.setText("DELETAR");
        btDel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDelActionPerformed(evt);
            }
        });

        btEdit.setText("EDITAR");
        btEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEditActionPerformed(evt);
            }
        });

        btLimpar.setText("LIMPAR");
        btLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btLimparActionPerformed(evt);
            }
        });

        btBusc.setText("BUSCAR");
        btBusc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btBuscActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lbCod)
                        .addComponent(lbAutor)
                        .addComponent(lbNome, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btInserir)
                        .addGap(14, 14, 14)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(btDel)
                        .addGap(39, 39, 39)
                        .addComponent(btEdit)
                        .addGap(41, 41, 41)
                        .addComponent(btLimpar)
                        .addGap(45, 45, 45)
                        .addComponent(btBusc))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(txtNome, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txtCod, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                        .addComponent(txtAutor, javax.swing.GroupLayout.Alignment.LEADING)))
                .addContainerGap(51, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbNome, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbAutor)
                    .addComponent(txtAutor, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbCod)
                    .addComponent(txtCod, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(73, 73, 73)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btInserir)
                    .addComponent(btDel)
                    .addComponent(btEdit)
                    .addComponent(btLimpar)
                    .addComponent(btBusc))
                .addContainerGap(110, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btInserirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btInserirActionPerformed
        String nm = txtNome.getText();
        String aut = txtAutor.getText();
        String cod = txtCod.getText();

        if (cont < 5) {
            if (!txtCod.getText().isBlank() && !txtNome.getText().isBlank() && !txtAutor.getText().isBlank()) {
                Livros liv = new Livros(nm, aut, cod);
                livro[cont] = liv;
                cont++;
                JOptionPane.showMessageDialog(rootPane, "Livro cadastrado com sucesso!");
                limparCampos();
            } else {
                JOptionPane.showMessageDialog(rootPane, "Nome, autor e código são obrigatórios.");
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Lista cheia. \nTente novamente.");
        }

    }//GEN-LAST:event_btInserirActionPerformed

    private void btDelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDelActionPerformed
        String cod = txtCod.getText();
        boolean achou = false;
        for (int i = 0; i < 5; i++) {
            if(cod.equals(livro[i].getCodigo())){
                int resp = JOptionPane.showConfirmDialog(rootPane, "Tem certeza que deseja excluir?");
                if (resp == 0){
                    achou = true;
                    Livros liv = new Livros("", "", "");
                    livro[i] = liv;
                    limparCampos();
                    cont--;
                    break;
                }
                
            }
            
        }
        if (!achou){
            JOptionPane.showMessageDialog(rootPane, "Livro não encontrado.");
        }
    }//GEN-LAST:event_btDelActionPerformed

    private void btEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEditActionPerformed
        String cod = txtCod.getText();
        boolean achou = false;
        for (int i = 0; i < 5; i++) {
            if(cod.equals(livro[i].getCodigo())){
                    achou = true;
                    String nm = txtNome.getText();
                    String aut = txtAutor.getText();                  
                    Livros liv = new Livros(nm, aut,cod);
                    livro[i] = liv;
                    JOptionPane.showMessageDialog(rootPane, "ALterado com sucesso.");
                    limparCampos();
                    break;
                }
                
            }      
        
    }//GEN-LAST:event_btEditActionPerformed

    private void btLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btLimparActionPerformed
       limparCampos();
    }//GEN-LAST:event_btLimparActionPerformed

    private void btBuscActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBuscActionPerformed
        String cod = txtCod.getText();
        boolean achou = false;
        for (int i = 0; i < 5; i++) {
            if (cod.equals(livro[i].getCodigo())){
                achou = true;
                txtNome.setText(livro[i].getNome());
                txtAutor.setText(livro[i].getAutor());
                break;
            }
        }
if (!achou){
     JOptionPane.showMessageDialog(rootPane, "Livro não encontrado");
}
    }//GEN-LAST:event_btBuscActionPerformed

    private void limparCampos(){
            txtAutor.setText("");
            txtCod.setText("");
            txtNome.setText("");
    
        }
        
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroDeLivros().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btBusc;
    private javax.swing.JButton btDel;
    private javax.swing.JButton btEdit;
    private javax.swing.JButton btInserir;
    private javax.swing.JButton btLimpar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lbAutor;
    private javax.swing.JLabel lbCod;
    private javax.swing.JLabel lbNome;
    private javax.swing.JTextField txtAutor;
    private javax.swing.JTextField txtCod;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
