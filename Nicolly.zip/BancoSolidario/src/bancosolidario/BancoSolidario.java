package bancosolidario;

public class BancoSolidario {

    public static void main(String[] args) {
        
    }
    
}
