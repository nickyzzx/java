package concessionaria;


public class AutomovelLuxo {
    
}
