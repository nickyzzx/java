
package arquivo;
import java.io.*;

public class Arquivo {

    public static void main(String[] args) {
        try {
            File arq = new File("/home/aluno/Downloads");
            
            if (arq.isFile()){
                System.out.println("É arquivo.");
                System.out.println("Nome: " + arq.getName());
                System.out.println("Tamanho: " + arq.length());
                System.out.println("Caminho: " + arq.getPath());
                
            }else if (arq.isDirectory()){
                System.out.println("É diretório/pasta.");
                System.out.println("Conteudo da pasta aluno: ");
                String[] vet = arq.list();
                for (String elemento : vet) {
                    System.out.println(elemento);
                    
                }
                
            }
            
        } catch (Exception e) {
            System.out.println("Falha" + e);

        }

    }//fechamento do método
    
}//fechamento da classe

