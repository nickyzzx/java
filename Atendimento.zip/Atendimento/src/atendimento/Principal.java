package atendimento;

import java.util.Scanner;


public class Principal {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        for (int i = 0; i < 3; i++) {
        System.out.println("Digite o código do curso: ");
        int codigo = sc.nextInt();
        System.out.println("Digite o nome do curso:");
        String nome = sc.next();
        //Curso = classe e c1 = objeto.
        Curso c1 = new Curso(codigo,nome);
        System.out.println(c1.toString());
        }
            
    }
    
}
