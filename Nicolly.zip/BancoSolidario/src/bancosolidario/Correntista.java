package bancosolidario;


public class Correntista {
    private long cpf;
    private String nome;
    private double saldo;

    public Correntista(long cpf, String nome, double saldo) {
        this.cpf = cpf;
        this.nome = nome;
        this.saldo = saldo;
    }

    public long getCpf() {
        return cpf;
    }

    public void setCpf(long cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        return "Correntista{" + "cpf=" + cpf + ", nome=" + nome + ", saldo=" + saldo + '}';
    }

    
}
