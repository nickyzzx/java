
package biblioteca02;


public class Livros {

    private String nome, autor;
    private String codigo;

    public Livros(String nome, String autor, String codigo) {
        this.nome = nome;
        this.autor = autor;
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    
       
    
    
}
