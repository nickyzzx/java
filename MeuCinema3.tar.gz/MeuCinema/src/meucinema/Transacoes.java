package meucinema;

import java.sql.*;
import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Transacoes {

    public ArrayList<Cinema> consultar(String nome) {
        Connection con = Conexao.conecta();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        ArrayList<Cinema> linha = new ArrayList<>();
        try {
            stmt = con.prepareStatement("select * from cinema where nome_filme='" + nome + "'");
            rs = stmt.executeQuery();
            if (rs.next()) {
                Cinema cm = new Cinema();

                cm.setAno(rs.getInt("ano_filme"));
                cm.setDesc(rs.getString("desc_filme"));
                cm.setNome(rs.getString("nome_filme"));
                linha.add(cm);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Falha ao consultar registro\n" + e);
        } finally {
            Conexao.fechaConexao(con, stmt, rs);
        }
        return linha;
    }

    public void inserir(Cinema cm) {
        Connection con = Conexao.conecta();
        PreparedStatement stmt = null;
        try {

            stmt = con.prepareStatement("insert into cinema (nome_filme, ano_filme, desc_filme) values (?, ?, ?);");
            stmt.setInt(2, cm.getAno());
            stmt.setString(1, cm.getNome());
            stmt.setString(3, cm.getDesc());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, cm.getNome() + " inserida com " + "sucesso!");

        } catch (SQLException e) {
            System.out.println("Falha ao inserir registro. " + e);
        } finally {
            Conexao.fechaConexao(con, stmt);
        }
    }

    public void alterar(Cinema cm, String nome) {
        Connection con = Conexao.conecta();
        PreparedStatement stmt = null;
        try {

            stmt = con.prepareStatement("update cinema set desc_filme =?, ano_filme =? where nome_filme=?");
            stmt.setInt(2, cm.getAno());
            stmt.setString(3, cm.getNome());
            stmt.setString(1, cm.getDesc());            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, cm.getNome() + " alterada com " + "sucesso!");

        } catch (SQLException e) {
            System.out.println("Falha ao alterar registro. " + e);
        } finally {
            Conexao.fechaConexao(con, stmt);

        }
    }

    public int deletar(String nome) {
        Connection con = Conexao.conecta();
        PreparedStatement stmt = null;
        int rs = 0;
        try {
            stmt = con.prepareStatement("delete from cinema where nome_filme='" + nome + "'");
            rs = stmt.executeUpdate();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao deletar" + e);

        } finally {
            Conexao.fechaConexao(con, stmt);

        }

        return rs;
    }
}
