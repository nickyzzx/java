package meucinema;
import java.sql.*;
import javax.swing.JOptionPane;


public class Transacoes {
    
    public void inserir(Cinema cm){
        Connection con =  Conexao.conecta();
        PreparedStatement stmt = null;
        try {
            
           stmt = con.prepareStatement("insert into cinema (nome_filme, ano_filme, desc_filme) values (?, ?, ?);");
           stmt.setInt(1, cm.getAno());
           stmt.setString(2, cm.getNome());
           stmt.setString(3, cm.getDesc());
           stmt.executeUpdate();
           JOptionPane.showMessageDialog(null, cm.getAno()+ "inserida com " + "sucesso!");
        
                   
        } catch (SQLException e) {
            System.out.println("Falha ao inserir registro. " + e); 
        }finally{
            Conexao.fechaConexao(con, stmt);
        }
    }
    
}
